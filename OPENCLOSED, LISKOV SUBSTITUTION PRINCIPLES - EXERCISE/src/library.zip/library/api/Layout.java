package library.api;

public interface Layout {


    String format(String time, String message, String level);
}
