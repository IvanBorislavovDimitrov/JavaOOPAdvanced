package library.api;

public interface File {


    void write(String text);

    long size();
}
