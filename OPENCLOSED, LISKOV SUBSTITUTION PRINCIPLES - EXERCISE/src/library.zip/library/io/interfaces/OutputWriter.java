package library.io.interfaces;

public interface OutputWriter {
    void writeLine(String line);
}
