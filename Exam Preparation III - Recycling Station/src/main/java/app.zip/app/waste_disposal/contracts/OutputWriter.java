package app.waste_disposal.contracts;

public interface OutputWriter {

    void writeLine(String line);
}
