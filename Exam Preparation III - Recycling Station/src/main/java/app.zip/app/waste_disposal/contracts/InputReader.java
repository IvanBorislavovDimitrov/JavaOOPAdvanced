package app.waste_disposal.contracts;

public interface InputReader {

    String readLine();
}
