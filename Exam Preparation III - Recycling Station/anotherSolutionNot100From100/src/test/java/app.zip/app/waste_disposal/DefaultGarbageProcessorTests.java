
package app.waste_disposal;

import app.models.BurnableImplMock;
import app.waste_disposal.contracts.GarbageDisposalStrategy;
import app.waste_disposal.contracts.GarbageProcessor;
import app.waste_disposal.contracts.ProcessingData;
import app.waste_disposal.contracts.Waste;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.Mockito;

import java.lang.annotation.Annotation;

public class DefaultGarbageProcessorTests {

    private GarbageProcessor garbageProcessor;

    @Before
    public void setUp() throws Exception {
        this.garbageProcessor = new DefaultGarbageProcessor();
    }

    @Test(expected = IllegalArgumentException.class)
    public void expectExceptionDueToTheLackOfAnnotation() {
        Waste waste = Mockito.mock(Waste.class);
        Mockito.when(waste.getWeight()).thenReturn(20D);
        Mockito.when(waste.getVolumePerKg()).thenReturn(20D);
        Mockito.when(waste.getName()).thenReturn("Pesho");

        this.garbageProcessor.processWaste(waste);
    }

    @Test
    public void test2() {
        Waste waste = new BurnableImplMock();
        GarbageDisposalStrategy recyclableGarbageStrategyMock = Mockito.mock(GarbageDisposalStrategy.class);

        ProcessingData processingData = Mockito.mock(ProcessingData.class);
        Mockito.when(processingData.getCapitalBalance()).thenReturn(8000D);
        Mockito.when(processingData.getEnergyBalance()).thenReturn(-200d);

        Mockito.when(recyclableGarbageStrategyMock.processGarbage(Mockito.isA(Waste.class))).thenReturn(processingData);

        Annotation annotation = waste.getClass().getAnnotations()[0];
        this.garbageProcessor.getStrategyHolder().addStrategy(annotation.annotationType(), recyclableGarbageStrategyMock);

        Assert.assertEquals(-200, processingData.getEnergyBalance(), 0.1);
        Assert.assertEquals(8000, processingData.getCapitalBalance(), 0.1);
    }

}
