package app.engine;

public interface Engine {
    void run();
}
