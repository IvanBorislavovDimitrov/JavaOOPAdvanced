package app.io;

import java.io.BufferedReader;
import java.io.InputStreamReader;

public interface InputReader {

    String readLine();

}
