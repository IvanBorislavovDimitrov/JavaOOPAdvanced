package app.io;

public interface OutputWriter {

    void writeLine(String line);
}
