package cresla.entities.containers;

import cresla.interfaces.AbsorbingModule;
import cresla.interfaces.EnergyModule;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;

public class ModuleContainerTests {

    private ModuleContainer moduleContainer;

    @Before
    public void setUp() throws Exception {
        this.moduleContainer = new ModuleContainer(20);
    }

    @Test
    public void addEnergyModule() {
        EnergyModule energyModule = Mockito.mock(EnergyModule.class);
        Mockito.when(energyModule.getEnergyOutput()).thenReturn(10);
        this.moduleContainer.addEnergyModule(energyModule);

        long totalEnergyOutput = this.moduleContainer.getTotalEnergyOutput();

        Assert.assertEquals(10L, totalEnergyOutput);
    }

    @Test
    public void addAbsorbingModule() {
        AbsorbingModule absorbingModule = Mockito.mock(AbsorbingModule.class);
        Mockito.when(absorbingModule.getHeatAbsorbing()).thenReturn(10);
        this.moduleContainer.addAbsorbingModule(absorbingModule);

        long totalEnergyOutput = this.moduleContainer.getTotalHeatAbsorbing();

        Assert.assertEquals(10L, totalEnergyOutput);
    }

    @Test
    public void getTotalEnergyOutput() {
        EnergyModule energyModule = Mockito.mock(EnergyModule.class);
        Mockito.when(energyModule.getEnergyOutput()).thenReturn(10);
        Mockito.when(energyModule.getId()).thenReturn(124134);
        this.moduleContainer.addEnergyModule(energyModule);

        EnergyModule energyModule1 = Mockito.mock(EnergyModule.class);
        Mockito.when(energyModule1.getEnergyOutput()).thenReturn(10);
        Mockito.when(energyModule1.getId()).thenReturn(123);
        this.moduleContainer.addEnergyModule(energyModule1);

        long totalEnergyOutput = this.moduleContainer.getTotalEnergyOutput();

        Assert.assertEquals(20L, totalEnergyOutput);
    }

    @Test
    public void getTotalHeatAbsorbing() {
        AbsorbingModule absorbingModule = Mockito.mock(AbsorbingModule.class);
        Mockito.when(absorbingModule.getHeatAbsorbing()).thenReturn(10);
        Mockito.when(absorbingModule.getId()).thenReturn(10);

        AbsorbingModule absorbingModule1 = Mockito.mock(AbsorbingModule.class);
        Mockito.when(absorbingModule1.getHeatAbsorbing()).thenReturn(10);
        Mockito.when(absorbingModule1.getId()).thenReturn(123);

        this.moduleContainer.addAbsorbingModule(absorbingModule);
        this.moduleContainer.addAbsorbingModule(absorbingModule1);

        long totalEnergyOutput = this.moduleContainer.getTotalHeatAbsorbing();

        Assert.assertEquals(20L, totalEnergyOutput);
    }

}
