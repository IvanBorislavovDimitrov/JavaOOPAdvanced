package app;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import panzer.contracts.*;
import panzer.entities.parts.ArsenalPart;
import panzer.entities.parts.EndurancePart;
import panzer.entities.parts.ShellPart;
import panzer.models.miscellaneous.VehicleAssembler;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

public class AssemblerTest {

    private Assembler assembler;

    @Before
    public void init() {
        this.assembler = new VehicleAssembler();
        ArsenalPart arsenalPart = new ArsenalPart("CA", 20, new BigDecimal(10), 1);
        assembler.addArsenalPart(arsenalPart);

        ShellPart shellPart = new ShellPart("CA", 20, new BigDecimal(10), 1);
        assembler.addShellPart(shellPart);

        EndurancePart endurancePart = new EndurancePart("CA", 20, new BigDecimal(10), 1);
        assembler.addEndurancePart(endurancePart);

    }

    // Returns the summed up weights of all parts in the assembler
    @Test
    public void testGetTotalWeight() {
        Assert.assertEquals(60, assembler.getTotalWeight(), 0.0001);
    }

    // Returns the summed up prices of all parts in the assembler
    @Test
    public void testGetTotalPrice() {

    }

    // Returns the summed up attackModifiers of all arsenal parts in the assembler
    @Test
    public void testGetTotalAttackModification() {

    }

    // Returns the summed up defenseModifiers of all shell parts in the assembler
    @Test
    public void testGetTotalDefenseModification() {

    }

    // Returns the summed up hitPointsModifiers of all endurance parts in the assembler
    @Test
    public void testGetTotalHitPointModification() {

    }

    // Adds an arsenal part to the assembler
    @Test
    public void testAddArsenalPart() {

    }

    // Adds a shell part to the assembler
    @Test
    public void testAddShellPart() {

    }

    // Adds an endurance part to the assembler
    @Test
    public void testAddEndurancePart() {
    }

}
