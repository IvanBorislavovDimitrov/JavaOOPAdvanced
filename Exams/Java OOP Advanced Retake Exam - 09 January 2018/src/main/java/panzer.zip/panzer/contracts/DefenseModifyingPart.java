package panzer.contracts;

public interface DefenseModifyingPart extends Part {
    int getDefenseModifier();
}
