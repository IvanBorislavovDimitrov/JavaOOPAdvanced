package panzer.contracts;

public interface InputReader {
    String readLine();
}