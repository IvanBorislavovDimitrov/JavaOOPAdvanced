package bg.softuni.models.enums;

public enum FragmentType {
    Nuclear,
    Cooling
}
