package bg.softuni.models.models.cores;

public class SystemCore extends BaseCore {

    public SystemCore(String type, Integer durability) {
        super(type, durability);
    }
}
