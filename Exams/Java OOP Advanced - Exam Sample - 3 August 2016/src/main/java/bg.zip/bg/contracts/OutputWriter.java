package bg.contracts;

public interface OutputWriter {

    void writeLine(String line);
}
