package bg.contracts;

public interface Engine {
    void run();
}
