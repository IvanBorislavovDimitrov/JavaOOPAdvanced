package callofduty.core;

import callofduty.interfaces.MissionControl;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.lang.reflect.Field;

public class MissionManagerTests {

    private static final Integer MISSION_ID_MAXIMUM_LENGTH = 8;

    private static final Double MISSION_RATING_MINIMUM_VALUE = 0D;

    private static final Double MISSION_RATING_MAXIMUM_VALUE = 100D;

    private static final Double MISSION_BOUNTY_MINIMUM_VALUE = 0D;

    private static final Double MISSION_BOUNTY_MAXIMUM_VALUE = 100000D;

    private MissionControl missionControl;

    @Before
    public void setUp() throws Exception {
        this.missionControl = new MissionControlImpl();
    }

    @Test
    public void testConstants() throws Exception {
        Field mission_id_maximum_length = this.missionControl.getClass().getDeclaredField("MISSION_ID_MAXIMUM_LENGTH");
        mission_id_maximum_length.setAccessible(true);

        Field mission_rating_minimum_value = this.missionControl.getClass().getDeclaredField("MISSION_RATING_MINIMUM_VALUE");
        mission_rating_minimum_value.setAccessible(true);

        Field mission_rating_maximum_value = this.missionControl.getClass().getDeclaredField("MISSION_RATING_MAXIMUM_VALUE");
        mission_rating_maximum_value.setAccessible(true);

        Field mission_bounty_minimum_value = this.missionControl.getClass().getDeclaredField("MISSION_BOUNTY_MINIMUM_VALUE");
        mission_bounty_minimum_value.setAccessible(true);

        Field mission_bounty_maximum_value = this.missionControl.getClass().getDeclaredField("MISSION_BOUNTY_MAXIMUM_VALUE");
        mission_bounty_maximum_value.setAccessible(true);

        Assert.assertEquals(MISSION_ID_MAXIMUM_LENGTH, mission_id_maximum_length.get(this.missionControl));
        Assert.assertEquals(MISSION_RATING_MINIMUM_VALUE, mission_rating_minimum_value.get(this.missionControl));
        Assert.assertEquals(MISSION_RATING_MAXIMUM_VALUE, mission_rating_maximum_value.get(this.missionControl));
        Assert.assertEquals(MISSION_BOUNTY_MINIMUM_VALUE, mission_bounty_minimum_value.get(this.missionControl));
        Assert.assertEquals(MISSION_BOUNTY_MAXIMUM_VALUE, mission_bounty_maximum_value.get(this.missionControl));

    }
}
